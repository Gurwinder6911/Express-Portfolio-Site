const ProjectController = require('./ProjectController')
const PostController = require('./PostController')
const ServiceController = require('./ServiceController')
const SubscriberController = require('./ServiceController')
const { subscribe } = require('../routes/page')

module.exports = {

	project: ProjectController,
  post: PostController,
  service: ServiceController,
subscriber :SubscriberController
}
